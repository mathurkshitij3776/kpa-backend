from pydantic import BaseModel
from typing import Optional, Any
from datetime import date

# Nested fields for wheel-specifications
class WheelFields(BaseModel):
    axleBoxHousingBoreDia: Optional[str] = None
    bearingSeatDiameter: Optional[str] = None
    condemningDia: Optional[str] = None
    intermediateWWP: Optional[str] = None
    lastShopIssueSize: Optional[str] = None
    rollerBearingBoreDia: Optional[str] = None
    rollerBearingOuterDia: Optional[str] = None
    rollerBearingWidth: Optional[str] = None
    treadDiameterNew: Optional[str] = None
    variationSameAxle: Optional[str] = None
    variationSameBogie: Optional[str] = None
    variationSameCoach: Optional[str] = None
    wheelDiscWidth: Optional[str] = None
    wheelGauge: Optional[str] = None
    wheelProfile: Optional[str] = None

class WheelSpecificationSchema(BaseModel):
    formNumber: str
    submittedBy: str
    submittedDate: date
    fields: WheelFields

class WheelSpecResponseData(BaseModel):
    formNumber: str
    submittedBy: str
    submittedDate: date
    status: str = "Saved"

class GenericResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Any]

class BogieChecksheetSchema(BaseModel):
    formNumber: str
    submittedBy: str
    submittedDate: date
    adjustingtube: str
    cylinderbody: str
    pistontrunnion: str
    plungerspring: str
    axleguide: str
    bogieframecondition: str
    bolster: str
    bolstersuspensionbracket: str
    lowerspringseat: str
    bogieno: str
    dateofioh: date
    defectcommunications: str
    incomingpaintdate: str
    makeryearbuilt: str
    
    class Config:
        orm_mode = True