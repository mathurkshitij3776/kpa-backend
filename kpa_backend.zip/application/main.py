from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from application.database import SessionLocal, engine, Base  # absolute imports
from application.models import WheelSpecification, BogieChecksheet
from application.schema import (
    WheelSpecificationSchema,
    BogieChecksheetSchema,
    GenericResponse,
    WheelSpecResponseData
)

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/api/forms/wheel-specifications", response_model=GenericResponse)
def submit_wheel_spec(data: WheelSpecificationSchema, db: Session = Depends(get_db)):
    fields = data.fields.dict()
    record = WheelSpecification(
        formNumber=data.formNumber,
        submittedBy=data.submittedBy,
        submittedDate=data.submittedDate,
        **fields
    )
    db.add(record)
    db.commit()
    return {
        "success": True,
        "message": "Wheel specification submitted successfully.",
        "data": WheelSpecResponseData(
            formNumber=record.formNumber,
            submittedBy=record.submittedBy,
            submittedDate=record.submittedDate
        )
    }

@app.post("/api/forms/bogie-checksheet")
def submit_bogie(data: BogieChecksheetSchema, db: Session = Depends(get_db)):
    record = BogieChecksheet(
        form_number=data.formNumber,
        submitted_by=data.submittedBy,
        submitted_date=data.submittedDate
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return {
        "data": {"id": record.id},
        "message": "Bogie Checksheet submitted successfully",
        "success": True
    }