from sqlalchemy import Column, Integer, String, Date
from .database import Base

class WheelSpecification(Base):
    __tablename__ = "wheel_specifications"

    id = Column(Integer, primary_key=True, index=True)
    formNumber = Column(String, unique=True, nullable=False)
    submittedBy = Column(String, nullable=False)
    submittedDate = Column(Date, nullable=False)
    # Flattened fields
    axleBoxHousingBoreDia = Column(String, nullable=True)
    bearingSeatDiameter = Column(String, nullable=True)
    condemningDia = Column(String, nullable=True)
    intermediateWWP = Column(String, nullable=True)
    lastShopIssueSize = Column(String, nullable=True)
    rollerBearingBoreDia = Column(String, nullable=True)
    rollerBearingOuterDia = Column(String, nullable=True)
    rollerBearingWidth = Column(String, nullable=True)
    treadDiameterNew = Column(String, nullable=True)
    variationSameAxle = Column(String, nullable=True)
    variationSameBogie = Column(String, nullable=True)
    variationSameCoach = Column(String, nullable=True)
    wheelDiscWidth = Column(String, nullable=True)
    wheelGauge = Column(String, nullable=True)
    wheelProfile = Column(String, nullable=True)

class BogieChecksheet(Base):
    __tablename__ = "bogie_checksheet"

    id = Column(Integer, primary_key=True, index=True)
    submitted_by = Column(String, nullable=False)
    formNumber = Column(String, nullable=False)
    # bmbChecksheet
    adjustingtube = Column(String)
    cylinderbody = Column(String)
    pistontrunnion = Column(String)
    plungerspring = Column(String)
    # bogieChecksheet
    axleguide = Column(String)
    bogieframecondition = Column(String)
    bolster = Column(String)
    bolstersuspensionbracket = Column(String)
    lowerspringseat = Column(String)
    # bogieDetails
    bogieno = Column(String)
    dateofioh = Column(Date)
    defectcommunications = Column(String)
    incomingpaintdate = Column(String)
    makeryearbuilt = Column(String)